<BODY>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-fluid">
    <div class="row">

        <div class="col-md-9">
            <div class="panel panel-default">
                <div class="panel-body">

                    <div>

                        <ul class="nav nav-tabs" role="tablist">

                            <li role="presentation" class="active"><a href="#detail" aria-controls="home" role="tab"
                                                                      data-toggle="tab"> Embassy Detail Form </a></li>
                            <li role="presentation"><a href="#list" aria-controls="home" role="tab"
                                                       data-toggle="tab"> Embassy Detail List </a></li>

                        </ul>

                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="detail">
                                <div class="container" style="padding:5px;width:100%">

                                    <div class="table-responsive">
                                        <form action="<?php echo e(route ('embassy.store')); ?> " method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <table width="98%">

                                                <tr height="40">
                                                    <td width="28%"
                                                        align="right">
                                                        Code
                                                    </td>
                                                    <td width="02%" align="center">:</td>
                                                    <td>
                                                        <table width="100%">
                                                            <tr>
                                                                <td width="30%">
                                                                    <input class="form-control" id="id" name="id"
                                                                           type="hidden">

                                                                <td align="right">&nbsp;</td>

                                                                </td>


                                                            </tr>
                                                            </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>


                                                <tr height="40">
                                                    <td width="28%" align="right">Location</td>
                                                    <td width="02%" align="center">:</td>
                                                    <td><input type="text" class="form-control" id="NAME"
                                                               name="location" value=""
                                                               placeholder="Location">
                                                </tr>

                                                <tr height="40">
                                                    <td width="28%" align="right">Contact Person</td>
                                                    <td width="02%" align="center">:</td>
                                                    <td><input type="text" class="form-control" id="CONTACT_PERSON"
                                                               name="contact_person"
                                                               value=""
                                                               placeholder="Contact Person "
                                                               required></td>
                                                </tr>

                                                <tr height="40">
                                                    <td width="28%" align="right"> Position</td>
                                                    <td width="02%" align="center">:</td>
                                                    <td width="88%">
                                                        <table width="100%">
                                                            <tr>
                                                                <td width="40%">
                                                                    <input type="text" class="form-control"
                                                                           id="POSITION" name="position"
                                                                           value=""
                                                                           placeholder="Position "
                                                                           required>

                                                                </td>
                                                                <td width="02%">&nbsp;</td>
                                                                <td align="right">Mobile No</td>
                                                                <td align="center">:</td>
                                                                <td width="40%"><input type="text"
                                                                                       class="form-control"
                                                                                       id="MOBILE_NO"
                                                                                       name="mobile_no"
                                                                                       value=""
                                                                                       placeholder="Mobile No "
                                                                                       required>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>


                                                <tr height="40">
                                                    <td align="right" valign="top">Remarks</td>
                                                    <td align="center" valign="top">:</td>
                                                    <td><textarea class="form-control" rows="1" id="REMARKS"
                                                                  placeholder="Enter Remarks"
                                                                  name="remarks">
                                                        </textarea></td>
                                                </tr>


                                                <tr height="40">
                                                    <td align="right">&nbsp;</td>
                                                    <td align="center">&nbsp;</td>
                                                    <td>

                                                        <table class="table">
                                                            <tr>
                                                                <td width="50%">


                                                                    <input type="submit" value="save"
                                                                           class="btn btn-primary pull-right">
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>

                                            </table>
                                        </form>


                                    </div>
                                </div>
                            </div>


                            <div role="tabpanel" class="tab-pane" id="list">
                                <div class="container" style="padding:5px;width:100%">
                                    <div class="panel panel-default">
                                    </div>

                                    <div class="list-group">
                                        <div class="panel panel-default">
                                            <div class="panel-body">

                                                <div class="list-group">
                                                    <table width="100%" class="table table-striped" border="0">
                                                        <thead>
                                                        <tr>
                                                            <th>Code</th>
                                                            <th>Location</th>
                                                            <th>Contact Person</th>
                                                            <th>Position</th>
                                                            <th>Mobile No</th>
                                                            <th>&nbsp;</th>
                                                            <th>&nbsp;</th>
                                                        </tr>

                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                    
                                                                
                                                            
                                                            
                                                                
                                                                       
                                                                       
                                                            
                                                            
                                                                
                                                                       
                                                                       

                                                            
                                                            
                                                                
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                    
                                                                
                                                            
                                                            
                                                                
                                                                    
                                                                    
                                                                    
                                                                

                                                            
                                                            
                                                                
                                                                
                                                            
                                                        


                                                        </thead>

                                                        <tbody>
                                                        <?php
                                                        foreach ($embassys as $embassy){?>
                                                        <tr>
                                                            <td><?php echo $country->id ?></td>
                                                            <td><?php echo $country->loacation ?></td>
                                                            <td><?php echo $country->contact_person ?></td>
                                                            <td><?php echo $country->position ?></td>
                                                            <td><?php echo $country->mobile_no ?></td>

                                                            <td>
                                                                <form class="" method="POST"
                                                                      action="<?php echo e(route('embassy.destroy', $embassy->id)); ?>">
                                                                    <input type="hidden" name="_token"
                                                                           value="<?php echo e(csrf_token()); ?>">
                                                                    <input type="hidden" name="_method" value="delete"/>
                                                                    <a href="<?php echo e(route('embassy.edit', $embassy->id)); ?>"
                                                                       class="btn btn-primary">Edit</a>
                                                                    <input type="submit" class="btn btn-danger"
                                                                           onclick="return confirm('Confirm to Delete');"
                                                                           name="name " value="Delete">
                                                                </form>
                                                            </td>
                                                        </tr>
                                                        <?php } ?>

                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">

            <div class="panel panel-default">
                <div class="panel-body">
                    <table width="100%" border="0">
                        <tr>
                            <td width="40%">&nbsp;</td>

                            <td width="60%" align="center">
                                <button type="submit" class="btn btn-success"> Add
                                    New Embassy
                                </button>
                                </a>
                            </td>
                        </tr>
                    </table>

                    <table width="100%" class="table table-striped" border="0">
                        <thead>
                        <tr style="width:100%">
                            <th width="95%">Embassy List</th>
                            <th width="05%">&nbsp;</th>
                        </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>


    </div>
</div>
</BODY>
